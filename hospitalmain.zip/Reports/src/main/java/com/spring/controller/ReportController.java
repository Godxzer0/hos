package com.spring.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.spring.exception.DataNotFoundException;
import com.spring.model.Report;
import com.spring.service.ReportService;

@RestController
public class ReportController {
	
	@Autowired
	ReportService reportService;

	
	@PostMapping("/add")
	public void addPatientReport(@RequestBody Report report)
	{
		reportService.addReport(report);
	}
	
	@DeleteMapping("/deleteById/{patientId}")
	public void deleteReportbyId(@PathVariable("patientId") int patientId)
	{
		reportService.deleteReportbyId(patientId);
	}
	
	@GetMapping("/fetchById/{patientId}")
	public ResponseEntity<Report> fetchreportbyId(@PathVariable("patientId") int patientId)
	{
		Optional<Report> report=reportService.fetchReportsbyId(patientId);
		if(report.isPresent())
			return ResponseEntity.ok(report.get());
		throw new DataNotFoundException("Invalid Report");
	}

	@GetMapping("/fetch")
	public List<Report> fetchAll(){
		List<Report> report=reportService.fetchAllreports();
		return report;
	}
	@PutMapping(value="/updateById/{patientId}")
    public void updatePost(@PathVariable int patientId, @RequestBody Report report) {
     reportService.updateReport(patientId, report);
}
  
}
