package org.SpringBoot.Controller;

import org.SpringBoot.Model.Appointment;
import org.SpringBoot.Model.Doctor;
import org.SpringBoot.Model.Patient;
import org.SpringBoot.Model.ReferalDoctor;
import org.SpringBoot.Service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AdminController {
	
	@Autowired
	AdminService adminservice;	
	
	
	@GetMapping("/fetchallreferaldoctors")
	public Object getAllreferaldoctors() {
		return adminservice.getReferalDoctors();
	}
	
	@GetMapping("/fetchallreports")
	public Object getallreferaldoctors() {
		return adminservice.getReports();
	}
	
	@GetMapping("/fetchallappointments")
	public Object getallappointments() {
		return adminservice.getappointmentdetails();
	}
		
	@GetMapping("/fetchallpatients")
	public Object getallpatients() {
		return adminservice.getallpatients();
	}

	@GetMapping("/fetchalldoctors")
	public Object getalldoctors() {
		return adminservice.getallDoctors();
	}
	
	@PostMapping("/addreferaldoctor")
	public Object addref(@RequestBody ReferalDoctor referaldoctor) {
		return adminservice.addreferaldoctors(referaldoctor);
	}
	
	@PostMapping("/addappointment")
	public Object addappointment(@RequestBody Appointment appointment) {
		return adminservice.addappointment(appointment);
	}
	
	@PostMapping("/adddoctor")
	public Object adddoctors(@RequestBody Doctor doctor) {
		return adminservice.addDoctor(doctor);
	}
	
	@PostMapping("/addpatient")
	public Object adddoctors(@RequestBody Patient patient) {
		return adminservice.addPatient(patient);
	}
	
	}



