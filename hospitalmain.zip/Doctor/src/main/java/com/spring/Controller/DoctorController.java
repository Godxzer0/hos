package com.spring.Controller;

import java.util.Optional;

import org.hibernate.sql.Delete;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.endpoint.web.annotation.RestControllerEndpoint;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.exceptionHandling.DataNotFoundException;
import com.spring.Model.Doctor;
import com.spring.Repository.DoctorRepository;
import com.spring.Service.DoctorServices;

import java.util.List;



@RestController
public class DoctorController {
	
	@Autowired
	DoctorServices doctorServices;
	
	  @Autowired 
	  DoctorRepository doctorRepository;
	 
	

	@GetMapping("/fetch")
	public List<Doctor> getAllDoctors()
	{
		List<Doctor> doctor=doctorServices.fetchAllDoctors();
		return doctor;
	}
	
	@GetMapping("/fetchById/{id}")
	public ResponseEntity< Doctor> getDoctorById(@PathVariable("id") int id)
	{
      Optional <Doctor> doctor= doctorServices.fetchDoctorById(id);
      if(doctor.isPresent())
    	  return ResponseEntity.ok(doctor.get());
		throw new DataNotFoundException("Doctor Name Invalid");
	}
	
	@PostMapping(value="/add")
	public void addDoctorInfo(@RequestBody Doctor doctor)
	{
	 doctorServices.addDoctor(doctor);
	}
	
	@DeleteMapping("/deleteById/{id}")
	public void deletebyId (@PathVariable("id") int id) {
		doctorServices.deletebyId(id);
		 
	}
	@PutMapping(value="/updateById/{id}")
    public void updatePost(@PathVariable int id, @RequestBody Doctor doctor) {

      doctorServices.updatePost(id, doctor);
}
	
	
	  @GetMapping("/fetchByName/{doctorName}") 
	  public Doctor getDoctorByName(@PathVariable("doctorName") String doctorname){
		  Doctor doctor=doctorRepository.findBydoctorName(doctorname);
		  return doctor; 
		  }
	  
	  @GetMapping("/fetchByDepartment/{department}") 
	  public Doctor getDoctorBydepartment(@PathVariable("department") String department){
		  Doctor doctor=doctorRepository.findBydepartment(department);
		  return doctor; 
		  }

    
	  @GetMapping("/getallreferaldoctors")
		public Object getAllreferaldoctors() {
			return doctorServices.getReferalDoctors();
		}
		
		@GetMapping("/fetchallreports")
		public Object getallreferaldoctors() {
			return doctorServices.getReports();
		}
		
		@GetMapping("/fetchallappointments")
		public Object getallappointments() {
			return doctorServices.getappointmentdetails();
		}
		
		
		@GetMapping("/fetchallprescriptions")
		public Object getallprescriptions() {
			return doctorServices.getallprescriptions();
		}
		
		@GetMapping("/fetchallpatients")
		public Object getallpatients() {
			return doctorServices.getallpatients();
		}

}