package com.SpringBoot.Controller;

import java.util.List;
import java.util.Optional;

import org.SpringBoot.Exception.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.SpringBoot.Model.Appointment;
import com.SpringBoot.service.appointmentService;

@RestController
public class AppointmentController {
	
	@Autowired
	appointmentService appointmentservice;
	
	@PostMapping(value="/add")
	public void bookAppointment(@RequestBody Appointment appointment)
	{
		appointmentservice.bookAppointment(appointment);
	}
	
	@GetMapping("/fetch")
    public List<Appointment> getAllappointments()
    {
        List<Appointment> appointment=appointmentservice.fetchAllAppointment();
        return appointment;
    }
	
	@GetMapping("/fetchById/{id}")
	public ResponseEntity<Appointment> getappointmentbyid(@PathVariable("id") int id)
	{
		Optional<Appointment> appointment=appointmentservice.fetchAppointmentById(id);
		if(appointment.isPresent())
		 return ResponseEntity.ok(appointment.get());
		 throw new ResourceNotFoundException("There is no appointment present with the given patient Id ");
	}

}
